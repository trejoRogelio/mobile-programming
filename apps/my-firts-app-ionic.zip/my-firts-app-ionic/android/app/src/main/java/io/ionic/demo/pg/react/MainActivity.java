package io.ionic.demo.pg.react;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
